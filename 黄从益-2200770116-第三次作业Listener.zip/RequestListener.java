package com.gzu;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpServletRequest;  // 导入 HttpServletRequest
import java.util.logging.Logger;

@WebListener
public class RequestListener implements ServletRequestListener {
    private static final Logger logger = Logger.getLogger(RequestListener.class.getName());

    // 使用 ThreadLocal 存储每个请求的开始时间
    private static final ThreadLocal<Long> startTime = new ThreadLocal<>();

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        // 记录请求开始时间
        startTime.set(System.currentTimeMillis());

        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();  // 强制转换为 HttpServletRequest

        String remoteAddr = request.getRemoteAddr();  // 获取客户端 IP 地址
        String requestURI = request.getRequestURI();  // 获取请求 URI
        String method = request.getMethod();  // 获取请求方法（GET, POST 等）
        String queryString = request.getQueryString();  // 获取查询字符串
        String userAgent = request.getHeader("User-Agent");  // 获取 User-Agent

        // 记录请求信息，包括请求时间、方法、URI、查询字符串、客户端 IP 和 User-Agent
        logger.info(String.format(
                "{\"event\":\"requestInitialized\", \"time\":%d, \"method\":\"%s\", \"uri\":\"%s\", \"queryString\":\"%s\", \"clientIP\":\"%s\", \"userAgent\":\"%s\"}",
                System.currentTimeMillis(),  // 记录当前时间
                method,
                requestURI,
                queryString != null ? queryString : "N/A",  // 如果没有查询字符串则记录为 N/A
                remoteAddr,
                userAgent
        ));
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        long endTime = System.currentTimeMillis();  // 记录请求结束时间
        long duration = endTime - startTime.get();  // 计算处理时间（从请求开始到结束的时间）

        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();  // 强制转换为 HttpServletRequest

        // 记录请求结束信息，包括 URI 和处理时间
        logger.info(String.format(
                "{\"event\":\"requestDestroyed\", \"uri\":\"%s\", \"processingTime\":%d}",
                request.getRequestURI(),
                duration  // 请求处理时间
        ));

        // 清除线程局部变量以防止内存泄漏
        startTime.remove();
    }
}