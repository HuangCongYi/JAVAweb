import java.sql.*;

public class TeacherCRUD {
    private static final String URL = "jdbc:mysql://localhost:3306/employee_management";
    private static final String USER = "root";
    private static final String PASSWORD = "0401180055hcy";
    /*teacher表的批量插入练习，插入500个教师，每插入100条数据提交一次*/
    public void batchInsertTeachers() {
        String sql = "INSERT INTO teacher (id, name, course, birthday) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            for (int i = 1; i <= 500; i++) {
                pstmt.setInt(1, i); // 设置id
                pstmt.setString(2, "Teacher " + i); // 设置姓名
                pstmt.setString(3, "Course " + (i % 5)); // 设置课程
                pstmt.setDate(4, Date.valueOf("1980-01-01")); // 设置生日
                pstmt.addBatch(); // 添加到批量

                if (i % 100 == 0) {
                    pstmt.executeBatch(); // 每100条提交一次
                }
            }
            pstmt.executeBatch(); // 提交剩余的数据
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /*可滚动的结果集练习，只查看结果集中倒数第2条数据*/
    public void scrollResultSet() {
        String sql = "SELECT * FROM teacher";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.last()) {
                rs.previous(); // 倒数第二条
                System.out.println("倒数第二条教师: " + rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /*teacher的CRUD练习*/
    // 创建
    public void createTeacher(int id, String name, String course, Date birthday) {
        String sql = "INSERT INTO teacher (id, name, course, birthday) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setString(3, course);
            pstmt.setDate(4, birthday);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 读取
    public void readTeacher(int id) {
        String sql = "SELECT * FROM teacher WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + ", Name: " + rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 更新
    public void updateTeacher(int id, String name) {
        String sql = "UPDATE teacher SET name = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 删除
    public void deleteTeacher(int id) {
        String sql = "DELETE FROM teacher WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
