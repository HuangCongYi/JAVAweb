
public class Main {
    public static void main(String[] args) {
        TeacherCRUD crud = new TeacherCRUD();

        // 批量插入教师
        crud.batchInsertTeachers();

        // 读取某个教师
        crud.readTeacher(1);

        // 更新教师姓名
        crud.updateTeacher(1, "Updated Teacher");

        // 再次读取确认更新
        crud.readTeacher(1);

        // 删除教师
        crud.deleteTeacher(1);

        // 滚动结果集查看倒数第二条数据
        crud.scrollResultSet();
    }
}