package com.gzu;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@WebFilter("/*")  // 2. 使用 @WebFilter 注解配置过滤器, 应用于所有 URL 路径
public class LoginFilter implements Filter {

    // 4. 创建一个排除列表, 包含不需要登录就能访问的路径
    private static final List<String> EXCLUDED_PATHS = Arrays.asList(
            "/login",      // 登录路径
            "/register",   // 注册路径
            "/public"      // 公共资源路径
    );

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // 初始化代码
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // 将请求和响应转换为 HTTP 特定的对象
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // 3a. 获取当前请求的 URI
        String requestURI = httpRequest.getRequestURI();

        // 3a. 检查当前请求是否在排除列表中，或是否为登录/注册页面
        if (isExcludedPath(requestURI) || requestURI.endsWith("/login.jsp") || requestURI.endsWith("/register.jsp")) {
            chain.doFilter(request, response);  // 允许请求通过
            return;  // 结束当前方法
        }

        // 3b. 获取当前用户的会话
        HttpSession session = httpRequest.getSession(false);
        // 3b. 检查用户的 session 中是否存在表示已登录的属性（如 "user" 属性）
        boolean loggedIn = (session != null && session.getAttribute("user") != null);

        // 3c. 验证用户是否已登录
        if (loggedIn) {
            chain.doFilter(request, response);  // 已登录，允许请求继续
        } else {
            // 3d. 未登录，重定向到登录页面
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp");
        }
    }

    // 5. 实现一个方法来检查当前请求路径是否在排除列表中
    private boolean isExcludedPath(String requestURI) {
        return EXCLUDED_PATHS.stream().anyMatch(requestURI::startsWith);
    }

    @Override
    public void destroy() {
        // 资源释放代码（如果需要）
    }
}